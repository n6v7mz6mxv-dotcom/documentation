var user = 'PhiTien8888';
var pass = '4ra6a';

const Global = {
  currentProxyAuth: {
    username: user,
    password: pass
  }
};

let proxyAuthListener = null;
let POPUP_PARAMS = {};

// Thiết lập xác thực proxy
function setupProxyAuth() {
  if (proxyAuthListener) {
    chrome.webRequest.onAuthRequired.removeListener(proxyAuthListener);
  }

  proxyAuthListener = (details) => {
    console.log("onAuthRequired >>>: ", details);
    return {
      authCredentials: {
        username: Global.currentProxyAuth.username,
        password: Global.currentProxyAuth.password
      }
    };
  };

  chrome.webRequest.onAuthRequired.addListener(
    proxyAuthListener,
    { urls: ["<all_urls>"] },
    ["blocking"] // Sử dụng blocking cho Manifest V3
  );
}

// Xử lý messages từ popup hoặc content script
chrome.runtime.onMessage.addListener(
  function (request, sender, sendResponse) {
    console.log("Background received a message: ", request);

    POPUP_PARAMS = {};
    if (request.command && requestHandler[request.command]) {
      requestHandler[request.command](request);
    }
    // Giữ channel mở để tương thích với async response
    return true;
  }
);

// Khởi tạo xác thực proxy khi extension khởi động
setupProxyAuth();

console.log("Service worker initialized for proxy authentication");
