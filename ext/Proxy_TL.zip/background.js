// Chuỗi proxy
var proxy = "socks5://113.179.142.147:10000:PhiTien8888:4ra6a";

// Hàm tách chuỗi proxy và thiết lập cấu hình
function parseProxyString(proxyString) {
  // Xóa khoảng trắng và tách chuỗi
  const parts = proxyString.trim().split(':');
  let scheme = 'http'; // Mặc định là http
  let host, port, username = '', password = '';

  // Kiểm tra nếu chuỗi bắt đầu bằng socks5://
  if (proxyString.startsWith('socks5://')) {
    scheme = 'socks5';
    // Bỏ phần socks5://
    parts.shift(); // Xóa phần đầu tiên (socks5)
    if (parts[0].startsWith('//')) {
      parts[0] = parts[0].slice(2); // Xóa dấu // nếu có
    }
  }

  // Gán host và port
  host = parts[0];
  port = parseInt(parts[1], 10);

  // Nếu có hơn 2 phần, gán username và password
  if (parts.length > 2) {
    username = parts[2];
    password = parts[3] || ''; // Đảm bảo password không undefined
  }

  return {
    currentProxy: {
      host: host,
      port: port,
      scheme: scheme
    },
    currentProxyAuth: {
      username: username,
      password: password
    }
  };
}

// Cấu hình proxy và thông tin xác thực
const Global = parseProxyString(proxy);

let proxyAuthListener = null;
let POPUP_PARAMS = {};

// Thiết lập proxy server
function setupProxy() {
  chrome.proxy.settings.set(
    {
      value: {
        mode: "fixed_servers",
        rules: {
          singleProxy: {
            scheme: Global.currentProxy.scheme,
            host: Global.currentProxy.host,
            port: Global.currentProxy.port
          },
          bypassList: ["localhost", "127.0.0.1"] // Bỏ qua proxy cho localhost
        }
      },
      scope: "regular"
    },
    () => {
      if (chrome.runtime.lastError) {
        console.error("Lỗi khi thiết lập proxy:", chrome.runtime.lastError);
      } else {
        console.log("Đã thiết lập proxy:", Global.currentProxy);
      }
    }
  );
}

// Thiết lập xác thực proxy (chỉ nếu có username/password)
function setupProxyAuth() {
  if (proxyAuthListener) {
    chrome.webRequest.onAuthRequired.removeListener(proxyAuthListener);
  }

  // Chỉ thiết lập xác thực nếu có username
  if (Global.currentProxyAuth.username) {
    proxyAuthListener = (details) => {
      console.log("onAuthRequired >>>: ", details);
      return {
        authCredentials: {
          username: Global.currentProxyAuth.username,
          password: Global.currentProxyAuth.password
        }
      };
    };

    chrome.webRequest.onAuthRequired.addListener(
      proxyAuthListener,
      { urls: ["<all_urls>"] },
      ["blocking"]
    );
  } else {
    console.log("Không có thông tin xác thực, bỏ qua thiết lập proxy auth.");
  }
}

// Xử lý messages từ popup hoặc content script
chrome.runtime.onMessage.addListener(
  function (request, sender, sendResponse) {
    console.log("Background received a message: ", request);

    POPUP_PARAMS = {};
    if (request.command && requestHandler[request.command]) {
      requestHandler[request.command](request);
    }
    return true; // Giữ channel mở cho async response
  }
);

// Xử lý các command từ popup/content script
const requestHandler = {
  updateProxy: (request) => {
    if (request.proxyString) {
      const parsed = parseProxyString(request.proxyString);
      Global.currentProxy = parsed.currentProxy;
      Global.currentProxyAuth = parsed.currentProxyAuth;
      setupProxy();
      setupProxyAuth();
      console.log("Đã cập nhật proxy:", Global.currentProxy);
    }
  }
};

// Khởi tạo proxy và xác thực khi extension khởi động
setupProxy();
setupProxyAuth();

console.log("Service worker initialized for proxy authentication");