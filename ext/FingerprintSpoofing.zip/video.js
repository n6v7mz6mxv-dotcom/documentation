g_is_storage_ready = false;
function wait_for_storage_ready() {
    args = Array.prototype.slice.call(arguments);
    if (g_is_storage_ready == true) {
        var callback = args[0];
        args.shift();
        callback.apply(null, args);
    } else {
        g_storage_ready_callbacks.push(args);
    };
};

chrome.webNavigation.onCommitted.addListener(function(details) {
    wait_for_storage_ready(function(details) {
        chrome.tabs.executeScript(details.tabId, {file: "content.js", allFrames: true, matchAboutBlank: true, runAt: "document_start"}, function() {
            chrome.runtime.lastError;
        });
    }, details);
}, { url: [{ schemes: ["http", "https", "file"] }] });

function initialize_options() {
    g_is_storage_ready = true;
    while (g_storage_ready_callbacks.length > 0) {
        var callback_array = g_storage_ready_callbacks.shift();
        var callback = callback_array[0];
        callback_array.shift();
        callback.apply(null, callback_array);
    };
};
initialize_options();